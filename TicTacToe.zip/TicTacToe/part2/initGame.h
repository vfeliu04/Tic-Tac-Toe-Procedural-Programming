
Game *initGame( int size, int length );
